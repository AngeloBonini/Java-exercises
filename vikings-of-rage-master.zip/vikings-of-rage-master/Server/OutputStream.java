import java.io.*;

class OutputStream {
  DataOutputStream output[] = new DataOutputStream[2];
  
  int cont = 0;
}
