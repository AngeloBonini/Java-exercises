interface ILogica {
    void executa();
  } 