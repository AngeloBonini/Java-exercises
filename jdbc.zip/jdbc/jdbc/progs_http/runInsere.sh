#! /bin/bash

java -classpath .:hsql.jar Insere

