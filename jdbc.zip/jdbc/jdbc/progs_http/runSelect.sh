#! /bin/bash

java -classpath .:hsql.jar Select

