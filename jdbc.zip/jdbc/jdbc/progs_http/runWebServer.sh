#! /bin/bash

java -classpath .:hsql.jar org.hsql.WebServer

