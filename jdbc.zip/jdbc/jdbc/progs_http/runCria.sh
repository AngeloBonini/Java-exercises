#!/bin/bash

java -classpath hsql.jar:. Cria
exit;
