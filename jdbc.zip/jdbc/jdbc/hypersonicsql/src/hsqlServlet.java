/*
 * hsqlServlet.java
 */

// This dummy class is required only because
// the Servlets class must be in the root directory

import org.hsql.Servlet;

public class hsqlServlet extends Servlet {
  public hsqlServlet() {
    super("test");
  }
}
