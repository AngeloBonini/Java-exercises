/*
 * Record.java
 */

package org.hsql;

class Record {
  public Object data[];
  public Record next;
}

