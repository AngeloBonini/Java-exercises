#! /bin/bash

java -classpath .:hsql.jar org.hsql.Server

